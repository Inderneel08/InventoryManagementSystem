import React, { useEffect, useState } from 'react';
import { Route, Navigate, useLocation } from 'react-router-dom';

const checkAuthentication = async () => {
  try {
    const response = await fetch('http://localhost:8080/validate', {
      headers: {
        Authorization: `Bearer ${localStorage.getItem('token')}`,
      },
    });

    if (response.ok) {
      return true;
    } else {
      localStorage.removeItem('token');
      return null;
    }
  } catch (error) {
    console.error('Authentication error:', error);
    return null;
  }
};


const ProtectedRoute = ({ children }) => {  
  const [isAuthenticated, setIsAuthenticated] = useState(null);
  const [loading, setLoading] = useState(true);
  let redirect = '/signIn';
  const location = useLocation();

  const jwtToken = localStorage.getItem('token');

  console.log(jwtToken);

  useEffect(() => {

    if (jwtToken != null) {
        checkAuthentication().then((result) => {
        setIsAuthenticated(result);
        setLoading(false);
      });
    }
    else{
      setIsAuthenticated(false);
      setLoading(false);
    }

  }, []);


  if(loading){
    return null;
  }

  if(isAuthenticated === true){
    return children;
  }
  else{

    if(location.pathname === '/' || location.pathname === '/products' || location.pathname === '/signIn'){  
      return children;
    }

    console.log(2);
    return <Navigate to={redirect} replace />;
  }

};

export default ProtectedRoute;
