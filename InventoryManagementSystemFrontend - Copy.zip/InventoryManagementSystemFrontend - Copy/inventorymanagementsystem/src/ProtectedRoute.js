import React, { useEffect, useState } from 'react';
import { Route, Navigate } from 'react-router-dom';

const checkAuthentication = async () => {
  try {
    const response = await fetch('http://localhost:8080/validate', {
      headers: {
        Authorization: `Bearer ${localStorage.getItem('token')}`,
      },
    });

    if (response.ok) {
      return true;
    } else {
      localStorage.removeItem('token');
      return null;
    }
  } catch (error) {
    console.error('Authentication error:', error);
    return null;
  }
};

const ProtectedRoute = ({ children }) => {  
  const [isAuthenticated, setIsAuthenticated] = useState(null);
  const [loading, setLoading] = useState(true);
  const redirect = '/signIn';

  useEffect(() => {
    const jwtToken = localStorage.getItem('token');

    console.log(jwtToken);

    if (jwtToken != null) {
      checkAuthentication().then((result) => {
        setIsAuthenticated(result);
        setLoading(false);
      });
    }
    else{
        setIsAuthenticated(false);
        setLoading(false);
    }
  }, []);

  
  return(null);

  if(loading){
    return null;
  }

  if(isAuthenticated === true){
    return children;
  }
  else{
    console.log(2);
    return <Navigate to={redirect} replace />;
  }

};

export default ProtectedRoute;
