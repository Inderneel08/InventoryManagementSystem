import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter, Routes, Route,Switch } from "react-router-dom";
import MyNavbar from './MyNavbar';
import Home from './Home';
import SignIn from './SignIn';
import Register from './Register';
import Contact from './Contact';
import AdminLogin from './adminLogin';
import ProtectedRoute from './ProtectedRoute';
import ProtectedHome from './ProtectedHome';
import { useEffect } from 'react';

function App() {

  return (
    <BrowserRouter>
        <Routes>
        
          <Route path="/" element={<ProtectedRoute> <MyNavbar/> </ProtectedRoute>} >
              <Route path="products"    element={<ProtectedRoute> <Home /> </ProtectedRoute> }></Route>
              <Route path="signIn"      element={<ProtectedRoute> <SignIn /> </ProtectedRoute> }></Route>
              <Route path="register"    element={<ProtectedRoute> <Register /> </ProtectedRoute> }></Route>
              <Route path="contact"     element={<ProtectedRoute> <Contact /> </ProtectedRoute> }></Route>
              <Route path="adminLogin"  element={<AdminLogin />}  ></Route>
              
              <Route path="category">
                <Route path="edibles" element={<Home />}></Route>
                <Route path="consumerDurables" element={<Home />}></Route>
                <Route path="garmentsAndOthers" element={<Home />}></Route>
                <Route path="toilet" element={<Home />}></Route>
                <Route path="toys" element={<Home />}></Route>
                <Route path="electronics" element={<Home />}></Route>
                <Route path="sports" element={<Home />}></Route>
                <Route path="stationary" element={<Home />}></Route>
                <Route path="music" element={<Home />}></Route>
              </Route>

              <Route path="protectedHome" element={<ProtectedRoute> <ProtectedHome /> </ProtectedRoute>} />

          </Route>
        </Routes>
    </BrowserRouter>

  );
}

export default App;
