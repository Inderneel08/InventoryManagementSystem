import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import MyNavbar from './MyNavbar';
import Home from './Home';
import SignIn from './SignIn';
import Register from './Register';
import Contact from './Contact';
import AdminLogin from './adminLogin';


function App() {
  return (
    <BrowserRouter>
        <Routes>
          <Route path="/" element={<MyNavbar/>} >
              <Route path="products"    element={<Home />}></Route>
              <Route path="signIn"      element={<SignIn />}></Route>
              <Route path="register"    element={<Register />}></Route>
              <Route path="contact"     element={<Contact />}></Route>
              <Route path="adminLogin"  element={<AdminLogin />}  ></Route>
              
              <Route path="category">
                <Route path="edibles" element={<Home />}></Route>
                <Route path="consumerDurables" element={<Home />}></Route>
                <Route path="garmentsAndOthers" element={<Home />}></Route>
                <Route path="toilet" element={<Home />}></Route>
                <Route path="toys" element={<Home />}></Route>
                <Route path="electronics" element={<Home />}></Route>
                <Route path="sports" element={<Home />}></Route>
                <Route path="stationary" element={<Home />}></Route>
                <Route path="music" element={<Home />}></Route>
              </Route>
          </Route>
        </Routes>
    </BrowserRouter>

  );
}

export default App;
