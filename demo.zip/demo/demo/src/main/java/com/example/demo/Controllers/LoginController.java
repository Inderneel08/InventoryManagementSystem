package com.example.demo.Controllers;

import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@Controller
public class LoginController {
    
    @PostMapping("/login")
    public String login(@RequestBody Map<String, String> registrationRequest)
    {
        
    }

}
