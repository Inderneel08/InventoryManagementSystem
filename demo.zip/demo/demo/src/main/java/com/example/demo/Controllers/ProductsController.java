package com.example.demo.Controllers;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ProductsController {

    @GetMapping("/welcome")
    public ResponseEntity<?> welcome() {

        return (ResponseEntity.ok("Reached welcome page"));
    }

}
