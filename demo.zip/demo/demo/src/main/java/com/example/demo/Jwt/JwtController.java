package com.example.demo.Jwt;

import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.ServiceLayer.CustomUserDetailsServices;


@RestController
public class JwtController {

    @Autowired
    private JwtTokenProvider jwtTokenProvider;

    @Autowired
    private CustomUserDetailsServices customUserDetailsServices;

    @PostMapping("/login")
    public ResponseEntity<?> generateToken(@RequestBody Map<String, String> jWtrequest) {
        UserDetails userDetails = customUserDetailsServices.loadUserByUsername(jWtrequest.get("email"));

        if(userDetails==null){
            return (ResponseEntity.status(403).body("Email id is not registered"));
        }

        if (!BCrypt.checkpw(jWtrequest.get("password"), userDetails.getPassword())) {

            return (ResponseEntity.status(403).body("Incorrect Password"));
        }

        String generatedToken = jwtTokenProvider.generateToken(userDetails);

        System.out.println("JWT token " + generatedToken);

        return ResponseEntity.ok(new JwtToken(generatedToken));
    }

}
