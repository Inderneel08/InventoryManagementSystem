package com.example.demo.Jwt;

import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.ServiceLayer.CustomUserDetailsServices;

@CrossOrigin(origins = "http://localhost:3000/")
@RestController
public class JwtController {

    @Autowired
    private JwtTokenProvider jwtTokenProvider;

    @Autowired
    private CustomUserDetailsServices customUserDetailsServices;

    @PostMapping("/login")
    public ResponseEntity<?> generateToken(@RequestBody Map<String, String> jWtrequest) {
        UserDetails userDetails = customUserDetailsServices.loadUserByUsername(jWtrequest.get("email"));

        System.out.println(userDetails.getUsername());
        System.out.println(userDetails.getPassword());

        if(userDetails==null){
            return (ResponseEntity.status(401).body("Email id is not registered"));
        }

        if (!BCrypt.checkpw(jWtrequest.get("password"), userDetails.getPassword())) {

            return (ResponseEntity.status(401).body("Incorrect Password"));
        }

        String generatedToken = jwtTokenProvider.generateToken(userDetails);

        System.out.println("JWT token " + generatedToken);

        return ResponseEntity.ok(new JwtToken(jWtrequest.get("email"),generatedToken));
    }

    @PostMapping("/adminLogin")
    public void generateTokenForAdmin(@RequestBody Map<String, String> jWtrequest)
    {
        System.out.println(jWtrequest);

        System.out.println(jWtrequest.get("email"));
    }


    @GetMapping("/validate")
    public ResponseEntity<?> validateTokenIdentity()
    {
        return(ResponseEntity.ok("VALIDATED"));
    }

}
