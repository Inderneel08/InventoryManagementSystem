package com.example.demo.Security;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import com.example.demo.Jwt.JwtTokenProvider;

@Component
public class JwtAutheticationFilter extends OncePerRequestFilter {

    @Autowired
    private JwtTokenProvider jwtTokenProvider;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response,
            FilterChain filterChain)
            throws ServletException, IOException {

        // Get JWT header.
        // Bearer.
        // Validate the header.

        System.out.println(request);

        String requestTokenHeader = request.getHeader("Authorization");

        String jwtToken = null;

        System.out.println(requestTokenHeader);

        if (requestTokenHeader != null && requestTokenHeader.startsWith("Bearer ")) {
            System.out.println("Not Null");
            jwtToken = requestTokenHeader.substring(7);

            System.out.println("Here");

            if (!jwtTokenProvider.isTokenExpired(jwtToken)) {

                System.out.println(1);

                if(jwtTokenProvider.validateToken(jwtToken)){

                    System.out.println(2);

                    filterChain.doFilter(request, response);
                }
            }

        } else {
            String servletPath = request.getServletPath();

            if((servletPath.equals("/login"))||(servletPath.equals("/register"))){
                filterChain.doFilter(request,response); 
            }
        }
    }

}
